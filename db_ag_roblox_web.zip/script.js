// Platzhalter für künftige JavaScript-Funktionen
console.log("DB AG Roblox Web-App geladen.");